from project.booths.booth import Booth


class OpenBooth(Booth):

    PRICE_PER_PERSON = 2.5
