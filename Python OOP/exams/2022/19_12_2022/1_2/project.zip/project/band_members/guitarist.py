from project.band_members.musician import Musician


class Guitarist(Musician):

    SKILLS_AVAILABLE = ["play metal", "play rock", "play jazz"]
