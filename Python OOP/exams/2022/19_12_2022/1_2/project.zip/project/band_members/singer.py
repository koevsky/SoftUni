from project.band_members.musician import Musician


class Singer(Musician):

    SKILLS_AVAILABLE = ["sing high pitch notes", "sing low pitch notes"]

