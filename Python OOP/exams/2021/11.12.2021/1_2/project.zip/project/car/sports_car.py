from project.car.car import Car


class SportsCar(Car):

    MIN = 400
    MAX = 600


