from project.car.car import Car


class MuscleCar(Car):
    
    MIN = 250
    MAX = 450



