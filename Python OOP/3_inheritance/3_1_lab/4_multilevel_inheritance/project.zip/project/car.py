from project.vehicle import Vehicle

class Car(Vehicle):
    def drive(self):
        return "driving..."
